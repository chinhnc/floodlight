package net.floodlightcontroller.topology;

import net.floodlightcontroller.routing.IRoutingService;

public interface ITopologyPathFinding extends IRoutingService {

}
